# Assignment3
Machine learning Usecases

#
Documentation
https://codelabs-preview.appspot.com/?file_id=11DSsHYhbcXAermrSB8jMmg8yW57q2vdM6-R68PQTtCM#1

#Sales Prediction
https://colab.research.google.com/drive/1bP_5Odm4rhc-kB6QtF2Y60m7VPhUd_gQ

#Recommendation
https://colab.research.google.com/drive/1kNV_hzye75w16Py6MXOqRhdeCbDQjxKE

#CLV
https://colab.research.google.com/drive/19YlQ666HOv0NmVRp5V8vYlLPsFuc_l8J
